# C# R.A.T Client
This is the client version of the c# R.A.T  
This will run on the target's machine and will connect to your machine via Tcp/IP  
You will need to download [R.A.T Server](https://github.com/AdvancedHacker101/C-Sharp-R.A.T-Server) to your computer to accept incoming clients  
This client depedns on .NET Framework, and windows.  
**Planning to extend to various platforms like:**  
- [x] [Android](https://github.com/AdvancedHacker101/android-R.A.T-Client)
- [x] [Linux](https://github.com/AdvancedHacker101/C-R.A.T-Client-Linux)
- [x] [Browser](https://github.com/AdvancedHacker101/Javascript-Botnet-C-Sharp) (JS Botnet)
- [ ] HTTP Server (via php backdoors, node modules, python modules etc.)

Some of the R.A.T Features are:  
- Keylogger
- Remote Desktop
- Mic And Cam Spy
- Remote Cmd Prompt
- Process and File manager
- Fun Menu (hiding Desktop icons, Clock, Taskbar, showing messagebox, triggering windows sound effects)
- DDoS with target validation
- Password manager (supporting: Internet Explorer, Google Chrome, Firefox)

Firefox password harvesting depends on NirSoft password fox.  
Other two browsers are implemented in the code.  
**I plan to add more features like:**
- [x] Scripting (Server side plugins can do this)
- [ ] Dns Server spoofing using [c# Dns Server](https://github.com/AdvanceHacker101/c-sharp-Dns-Server)
- [x] [Proxy Server](https://github.com/AdvancedHacker101/C-Sharp-Proxy-Server) (for web content modification)
- [ ] Pivoting (infecting other machines in the local network)
- [ ] Registry editing
- [ ] Windows System password phising attack
- [x] Probing methods (for ex. start at system start, prevent from deleting file, maybe get UAC elevated)
- [x] Hiding program on start (Available as an opt-in)
- [x] Maybe http/s server for browser clients (See JS Botnet server plugin)
- [x] Support for resolving Dns to ipv4 address
- [ ] Connect to linux server

And only use this on other peoples machine if you have thier permission, otherwise you can test it on a VM (Virtul Machine)  
This is not a dangerous virus so if you start it on your own machine and don't send any commands from the server you can safely just close the program like nothing happend  
## More information
You can view the project licence [here](https://github.com/AdvancedHacker101/C-Sharp-R.A.T-Client/blob/master/LICENSE)  
You can read the code of conduct [here](https://github.com/AdvancedHacker101/C-Sharp-R.A.T-Client/blob/master/CODE_OF_CONDUCT.md)  
You can read how to contribute [here](https://github.com/AdvancedHacker101/C-Sharp-R.A.T-Client/blob/master/CONTRIBUTING.md)  

*Happy Coding!*  

**\-Advanced Hacker 101**
